import React, { useEffect, useRef, useState } from "react";

import classes from "./GalleryDetail.module.css";

const GalleryDetail = (props) => {

    const [width, setWidth] = useState(window.innerWidth)
    const [height, setHeight] = useState(window.innerHeight)

    const resizeHandler = () => {
        setWidth(window.innerWidth)
        setHeight(window.innerHeight)
    }

    useEffect(() => {
        window.addEventListener('resize', resizeHandler)

        return () => window.removeEventListener('resize', resizeHandler)
    }, [])




    const detailPages = props.detailPages[0]
    let scrollLength = 0
    let heightPage= 0
    const pageRef = useRef(null)
    const [scrollLength1, setScrollLength1] = useState(0)

    const dateObject = new Date(detailPages.Date);
    const year = dateObject.getFullYear();
    const month = (dateObject.getMonth() + 1).toString();

    const touchHandler = (eventStart) => {
        let currentTouch = eventStart.changedTouches[0].clientY
        let currentTimeStamp = 0

        const touchMoveHandler = (eventMove) => {

            const timeStamp = currentTimeStamp === 0 ? 0 : eventMove.timeStamp - currentTimeStamp

            console.log(timeStamp);

            currentTimeStamp = eventMove.timeStamp
            
            const moveTouch = eventMove.changedTouches[0].clientY
            
            const checkDirection = (currentTouch - moveTouch)
            const tempLength = (scrollLength + checkDirection)

            currentTouch = moveTouch

            const calculateScroll = () => {
                if (tempLength >= 0 && tempLength <= ((heightPage - height)))
                    return tempLength
                else if (tempLength < 0 )
                    return 0
                else if (tempLength > ((heightPage - height)))
                    return ((heightPage - height))
    
            }
    
            scrollLength = calculateScroll()
            setScrollLength1(scrollLength);

        }

        const touchEndHandler = (eventEnd) => {

            window.removeEventListener('touchmove', touchMoveHandler)

        }

        window.addEventListener('touchmove', touchMoveHandler)

        window.addEventListener('touchend', touchEndHandler)

        return () => window.removeEventListener('touchend', touchEndHandler)
    }

    useEffect(() => {
        window.addEventListener('touchstart', touchHandler)

        return () => window.removeEventListener('touchstart', touchHandler)
    }, [])

    useEffect(() => {
        window.addEventListener('wheel', scrollHandler)
        return () => window.removeEventListener('wheel', scrollHandler)
    }, [])

    useEffect(() => {
        if (pageRef.current) {
            heightPage = pageRef.current.clientHeight;
        }
    }, [pageRef])

    const scrollHandler = (e) => {
        // setScrollLength(Number(scrollLength) + Number(e.deltaY))
        const tempLength = (scrollLength + Number(e.deltaY))

        const calculateScroll = () => {
            if (tempLength >= 0 && tempLength <= ((heightPage - height)))
                return tempLength
            else if (tempLength < 0 )
                return 0
            else if (tempLength > ((heightPage - height)))
                return ((heightPage - height))

        }

        scrollLength = calculateScroll()
        setScrollLength1(scrollLength);
    }

    return (
        <div ref={pageRef} className="w-full relative flex flex-col items-center">
            {/* Photo Jumbotron  */}
            <div className={`w-full relative flex flex-col justify-center items-center text-white bg-cover bg-center bg-no-repeat ${classes['bg-jumbotron']}`} style={{ height: '90vh', backgroundImage: `url("storage/${detailPages.Img[0]}")`}}>
                {/* <div className={`w-full text-white bg-cover bg-center bg-no-repeat ${classes['bg-jumbotron']}`} style={{ height: '60vh', backgroundImage: `url("storage/${detailPages.Img[0]}")`, clipPath: `url(#textJumbotron)`, filter: 'brightness(150%) saturate(150%)' }} />
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1884 0" width={1884}>
                <defs>
                    <clipPath id="textJumbotron">
                        <text x={(1437 - 451) / 2} y="50" className="w-7 text-6xl font-bold">
                        {detailPages.Name}
                        </text>
                    </clipPath>
                </defs>
                </svg> */}
                <span className="text-9xl font-bold mix-blend-difference text-center" style={{ transform: `translateY(${scrollLength1}px)` }}>{detailPages.Name}</span>
            </div>

            <div className="w-full relative flex flex-col items-center z-10" style={{ backgroundColor: '#e0dcdc', transform: `translateY(-${scrollLength1}px)` }}>
                <div style={{ maxWidth: '680px' }}>
                    <div className="my-6 flex flex-col">
                        <span>JAPAN {year}</span>
                        {/* <span>{detailPages.Name}</span> */}
                        <span>{`${year}.${month}`}</span>
                    </div>
                    <div className="mb-5 flex flex-col">
                        <span>{detailPages.City_Name}</span>
                        <span>Completed</span>
                    </div>

                    <div className="mb-16">
                        <span>{detailPages.DescriptionEn}</span>
                    </div>

                    {/* Image Showup */}
                    <div>
                        {detailPages.Img.map((item, index) => {
                            return (
                                <div key={index}>
                                    <img src={`storage/${item}`} alt="" />
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
            
        </div>
    );
};

export default GalleryDetail;
